package com.kh.practice.student.controller;

import com.kh.practice.student.model.vo.Student;

public class StudentController {
	private Student[] sArr = new Student[5];
	
	public static final int CUT_LINE = 60;
		
	
	
	public StudentController() {
		
	}
	public Student [] printStudent() {
		
	}
	public int sumScore() {
		
	}
	public double [] avgScore() {
		
	}
}

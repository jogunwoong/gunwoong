package com.kh.practice.student.view;

import com.kh.practice.student.controller.StudentController;

public class StudentMenu {
	
	private StudentController ssm  = new StudentController();
		
	
	
	public StudentMenu() {
		
		
		
		
	}

}
